# Diagnose a source missing from search
Baseframe Knowledge | Operational runbook

Portfolio demonstration; procedures apply to the fictional API contract in this sample set.

## Trigger and scope
Use this runbook when a submitted source is absent from expected search results. You need the collection ID, source ID, job ID, and a token with jobs:read and search:read. Do not collect tokens or document bodies in incident notes.

## 1. Establish the ingestion state
Read GET /jobs/{job_id}. If queued or processing, check again using the documented polling interval. After five minutes, escalate for investigation; the job may still complete. If failed, record error.code and error.message. If succeeded, proceed to retrieval checks. A 404 requires checking the workspace and ID before treating the job as lost.

## 2. Verify the request context
Confirm that the search uses the same collection as the create request. Confirm the token belongs to that workspace and has search:read. A 403 is an authorization problem; expanding the collection's access is not a troubleshooting shortcut.

## 3. Use a diagnostic query
Search for a distinctive phrase in the submitted text, with limit set to 20. Compare returned source IDs with the expected source ID. If it appears for the diagnostic query but not the user query, classify the issue as retrieval relevance and review wording and document context. If absent after succeeded, escalate for indexing investigation. An empty result alone does not prove an index outage.

## 4. Handle request failures
For 429, wait for Retry-After. For 500 or 503, retry with exponential backoff and jitter, at most five attempts. Do not rerun source creation with a new idempotency key: it can return source_exists and does not repair indexing.

## Escalation record
Capture UTC timestamp, endpoint, HTTP status, X-Request-ID, workspace identifier, collection ID, source ID, job ID, terminal state, and a sanitized description of the query. Include whether other sources are affected. Keep source text and secrets out of tickets unless an approved secure diagnostic process specifically requires them.

## Resolution criteria
For an indexing issue, confirm the job succeeded and the source appears for the diagnostic query. For a relevance issue, verify the original user task with an agreed expected result. Record the cause, corrective action, and any needed content or monitoring change. Restoring diagnostic retrieval alone does not establish broader search quality.
