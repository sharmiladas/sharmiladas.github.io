# Ingest your first document and verify search
Baseframe Knowledge | Developer quickstart

Portfolio demonstration for a fictional API. The .example hosts are placeholders and will not run. The walkthrough illustrates a developer journey against the contract in the API reference.

## What you will build
Submit a document, wait for ingestion, and retrieve its excerpt. Success means that ingestion reports succeeded and a search returns your source_id. This is retrieval verification; it does not establish answer quality or production readiness.

## Before you begin
For an implementation of this contract, you would need curl, Python 3, a collection named col_demo, and a workspace token with sources:write, jobs:read, and search:read. A collection must already exist; collection creation is outside this sample.

Store the token in an environment variable. Do not commit it or put it in client-side browser code. Read it without adding the value to shell history:
```bash
read -r -s -p 'API token: ' BASEFRAME_TOKEN
export BASEFRAME_TOKEN
```

## 1. Prepare the document
Create source.json:
```json
{"external_id":"onboarding-guide","title":"Create an API token","content":"Open Workspace settings. Select API tokens. Choose Create token.","source_url":"https://docs.example.com/api-tokens","language":"en"}
```
Use an approved source. This endpoint stores the supplied text; it does not download source_url. Keep the URL so readers can verify the excerpt against its origin.

## 2. Submit it
```bash
curl --fail-with-body --silent --show-error   'https://api.baseframe.example/v1/collections/col_demo/sources'   --header "Authorization: Bearer $BASEFRAME_TOKEN"   --header 'Content-Type: application/json'   --header 'Idempotency-Key: onboarding-guide-2026-10-06-v1'   --data-binary @source.json > ingestion.json
```
Expected HTTP status: 202. Extract job_id and source_id only after the command succeeds:
```bash
JOB_ID=$(python3 -c 'import json; print(json.load(open("ingestion.json"))["job_id"])')
SOURCE_ID=$(python3 -c 'import json; print(json.load(open("ingestion.json"))["source_id"])')
```
Retain the key for network retries of this exact request. A new key does not bypass duplicate external_id protection.

## 3. Check ingestion
```bash
curl --fail-with-body --silent --show-error   "https://api.baseframe.example/v1/jobs/$JOB_ID"   --header "Authorization: Bearer $BASEFRAME_TOKEN"
```
For queued or processing, wait at least two seconds before checking again. Increase the interval up to 30 seconds. For succeeded, continue. For failed, inspect error and stop. Stop polling after five minutes and investigate with the job ID; do not assume failure or resubmit automatically.

## 4. Retrieve the document
```bash
curl --fail-with-body --silent --show-error   'https://api.baseframe.example/v1/collections/col_demo/search'   --header "Authorization: Bearer $BASEFRAME_TOKEN"   --header 'Content-Type: application/json'   --data '{"query":"How do I create an API token?","limit":3}' > search.json
```
Verify that results contains the source you created:
```bash
python3 - "$SOURCE_ID" <<'PY'
import json, sys
results = json.load(open('search.json'))['results']
assert any(item['source_id'] == sys.argv[1] for item in results), 'Expected source was not retrieved'
print('Verified: the ingested source appears in search results.')
PY
```

## Troubleshoot
- 202 but no result: check the job's terminal state before searching.
- 401: verify that the token is set and valid.
- 403: compare token scopes with the endpoint requirements.
- 409 source_exists: the collection already contains this external_id. Verify the existing source or use a distinct ID for a separate document.
- Empty results after success: check the collection ID, search terms, and source text. Ingestion success does not guarantee relevance for every query.
- 429: pause for Retry-After; avoid tight polling loops.

## Next steps
Use the API reference for production retry handling. Before expanding the collection, define source ownership, review dates, access policy, and a set of representative retrieval tests. Clear the token from your shell when finished: unset BASEFRAME_TOKEN.
