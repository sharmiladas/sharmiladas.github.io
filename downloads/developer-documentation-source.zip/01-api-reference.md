# Source ingestion API reference
Baseframe Knowledge API | API reference | Version 1.0

Portfolio demonstration. Baseframe Knowledge is a fictional product; the endpoints, limits, and responses below define an illustrative contract. No live service is provided.

## Overview
Ingest approved documentation into a searchable collection. Ingestion is asynchronous: accepting a source creates a job, and the source becomes searchable only after that job succeeds. The collection's access policy applies to every source; this sample does not support document-specific permissions.

Base URL: https://api.baseframe.example/v1
All requests use HTTPS. Send a bearer token in Authorization. Tokens are scoped to a workspace; collection IDs from another workspace return 404. JSON requests require Content-Type: application/json.

## Create a source
POST /collections/{collection_id}/sources
Required scope: sources:write

Path parameter: collection_id (string), the collection to receive the source.
Headers: Authorization (required); Content-Type (required); Idempotency-Key (required, 1–128 ASCII characters).

Request fields:
- external_id: required string, 1–128 characters; unique within a collection. Use a stable identifier from the source system.
- title: required string, 1–200 characters.
- content: required string, UTF-8 plain text, 1–100,000 bytes.
- source_url: required absolute HTTPS URL; stored as provenance, never fetched by this endpoint.
- language: optional string; supported values en, fr, de, ja. Default en.

```bash
curl --request POST 'https://api.baseframe.example/v1/collections/col_demo/sources'   --header "Authorization: Bearer $BASEFRAME_TOKEN"   --header 'Content-Type: application/json'   --header 'Idempotency-Key: onboarding-guide-2026-10-06-v1'   --data '{"external_id":"onboarding-guide","title":"Create an API token","content":"Open Workspace settings. Select API tokens. Choose Create token.","source_url":"https://docs.example.com/api-tokens","language":"en"}'
```

202 Accepted:
```json
{"source_id":"src_demo","job_id":"job_demo","status":"queued"}
```
Location: /v1/jobs/job_demo
The response confirms acceptance, not search availability.

## Idempotency and duplicate handling
A key is retained for 24 hours within the workspace. Repeating the same key and body returns the original 202 response and IDs without creating another job. Reusing the key with a different body returns 409 idempotency_conflict. A new key with an existing external_id returns 409 source_exists. To change an existing source, use the replacement workflow; creating it again is not an update. Replacement is outside this sample's API surface.

## Get job status
GET /jobs/{job_id}
Required scope: jobs:read
200 OK:
```json
{"job_id":"job_demo","source_id":"src_demo","status":"succeeded","error":null}
```
status: queued, processing, succeeded, or failed. queued becomes processing; processing becomes succeeded or failed. Terminal states do not change. If failed, error contains code and message; the source is not searchable. Poll every two seconds, then increase to a maximum of 30 seconds. Stop on a terminal state. After five minutes, stop the client loop and retain the job ID for investigation; timeout does not cancel the job.

## Search a collection
POST /collections/{collection_id}/search
Required scope: search:read
Request: query (required string, 1–1,000 characters); limit (optional integer, 1–20, default 5).
Only successfully ingested sources are eligible. Search returns source excerpts, not generated answers.

```json
{"query":"How do I create an API token?","limit":3}
```
200 OK:
```json
{"results":[{"source_id":"src_demo","title":"Create an API token","source_url":"https://docs.example.com/api-tokens","excerpt":"Open Workspace settings. Select API tokens. Choose Create token.","score":0.92}]}
```
score is a ranking signal between 0 and 1, not a probability that the result is correct. Results are ordered by descending score. No matches returns {"results":[]} with 200.

## Errors and retry behavior
Errors use this envelope:
```json
{"error":{"code":"invalid_request","message":"content exceeds 100000 bytes","request_id":"req_demo"}}
```
- 400 invalid_request: correct the named field; do not retry unchanged.
- 401 unauthenticated: replace the expired or invalid token.
- 403 insufficient_scope: request the required token scope.
- 404 not_found: verify the ID and workspace.
- 409 idempotency_conflict or source_exists: reconcile the existing operation before retrying.
- 429 rate_limited: wait for Retry-After, expressed in seconds.
- 500 internal_error or 503 unavailable: retry with exponential backoff and jitter, at most five attempts; preserve the original idempotency key for create requests.

Limit: 60 requests per minute per workspace across these endpoints. Every response includes X-Request-ID. When escalating, include the request ID, endpoint, timestamp, and job ID if available. Omit tokens and source content.
