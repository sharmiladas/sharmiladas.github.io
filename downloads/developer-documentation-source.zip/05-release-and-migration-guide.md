# Migrate ingestion clients to API v1
Baseframe Knowledge | Release notes and migration guide

Portfolio demonstration. The legacy v0 behavior below is an invented comparison used to show how to document a breaking change.

## What changed
In the illustrative v0 API, source creation returned 201 after indexing completed. API v1 returns 202 immediately with source_id, job_id, and status: queued. Clients must check job status before using the source in search. API v1 also requires Idempotency-Key on create requests.

## Who needs to act
Update integrations that treat a successful create response as proof that a document is searchable, expect a 201 status, or retry create requests without retaining a key.

## Migration steps
1. Generate one idempotency key for each logical create operation and retain it with the request body.
2. Change the create success check from 201 to 202 and persist source_id and job_id.
3. Add GET /jobs/{job_id} polling with jobs:read. Start at two seconds, increase to a maximum of 30 seconds, and stop on succeeded or failed.
4. Run search verification only after succeeded. Handle failed as an explicit ingestion failure.
5. After five minutes, stop local polling and record the job ID for support. Do not treat the timeout as cancellation.
6. Exercise 400, 403, 409, 429, and 503 handling before rollout.

## Validate before rollout
Submit one approved test document into a test collection. Confirm 202 acceptance, terminal success, and retrieval of the same source_id. Repeat the identical create request with the same key and confirm the IDs do not change. Submit a different body with that key and confirm 409 idempotency_conflict. These are proposed contract checks; this portfolio package does not include a running service or executed integration-test results.

## Rollout and recovery
Enable the v1 client for a test collection first, then expand after validation. If the new client fails, stop new submissions and retain the accepted job IDs. Returning to the legacy client requires confirming that v0 is still supported and reconciling accepted v1 operations before resubmission. A client rollback does not undo server-side ingestion.

## Deprecation information
Before publishing this guide for a real product, add the v0 support deadline, affected client versions, support contact, and rollback window. This fictional example has no actual deprecation schedule.
