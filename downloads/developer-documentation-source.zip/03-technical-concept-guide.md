# How a document becomes a searchable source
Baseframe Knowledge | Technical concept guide

Portfolio demonstration. This guide describes the fictional system defined by the accompanying API contract.

## Audience and purpose
For engineers and content owners preparing documents for search or investigating missing results. This guide explains what happens after submission and what to check before ingesting content.

## The source lifecycle
The API validates the request, reserves the external_id, and creates a queued job. A worker moves the job to processing, normalizes the text, splits it into passages, and builds the search index. The source becomes eligible for retrieval only when the job reaches succeeded. Failed jobs do not expose partially indexed content.

After a 202 response, wait for the job to reach succeeded before searching. Indexing does not review the document for accuracy or freshness; the content owner must check those before submission.

## Source, passage, and result
A source represents one submitted document and its provenance URL. A passage is an internal unit used for retrieval. A search result exposes a relevant excerpt associated with the source ID, title, and URL. Internal passages are not public API resources in this sample.

Keep procedural context together. A passage that says “Select Delete” without the object, prerequisites, or effect can be retrieved accurately and still mislead the reader. Use specific headings, explicit nouns, and complete task steps. Place important conditions beside the action they qualify.

## Access policy
A token belongs to one workspace. The collection defines which sources a token may retrieve. All documents in a collection share the collection's access policy; there are no document-level overrides here. Separate restricted and broadly accessible content into different collections. Do not ingest confidential material into a collection with a wider audience.

## What the ranking score means
The score ranks how closely a result matches the query. A high-ranking result may still contain an outdated procedure. Open the source URL to check the instructions, and test retrieval with questions your users actually ask. Access is controlled by permissions, independently of the score.

## Prepare content for ingestion
- Stable identity: preserve external_id across the source system's lifecycle so ownership and changes remain traceable.
- Provenance: use a maintained source_url that resolves to the authoritative document.
- Task completeness: include prerequisites, actions, expected results, and recovery paths.
- Ownership: designate who approves changes and who handles retirement.
- Freshness: define review intervals according to how quickly the underlying feature changes.
- Access: validate the collection policy before submitting content.

## Common failure modes
Missing results can arise from a pending job, ingestion failure, the wrong collection, or a mismatch between query language and source wording. Incorrect results can arise from stale content, ambiguous procedures, or incomplete context. Investigate system state first, then inspect the content and query. Before resubmitting, check the existing job and confirm which collection you searched.

## Design tradeoffs
Asynchronous ingestion avoids holding the request open while indexing, but requires clients to track job state. Collection-level permissions simplify the contract, but require separate collections for different audiences. Each result includes an excerpt and its source URL. This API does not combine sources into an answer; an application that adds answer generation needs its own quality checks.
