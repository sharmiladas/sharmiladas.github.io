def graph_context(graph, start_id, depth=2):
    node_map={n["id"]:n for n in graph["nodes"]}
    frontier={start_id}; seen={start_id}; lines=[]
    for _ in range(depth):
        nxt=set()
        for a,rel,b in graph["edges"]:
            if a in frontier:
                lines.append(f'{node_map[a]["type"]}:{node_map[a]["name"]} --{rel}--> {node_map[b]["type"]}:{node_map[b]["name"]}')
                if b not in seen: nxt.add(b); seen.add(b)
            if b in frontier:
                lines.append(f'{node_map[a]["type"]}:{node_map[a]["name"]} --{rel}--> {node_map[b]["type"]}:{node_map[b]["name"]}')
                if a not in seen: nxt.add(a); seen.add(a)
        frontier=nxt
    return lines
