import re, json
from pathlib import Path

WEIGHTS = {
    "groundedness": .25, "factual_consistency": .20, "completeness": .20,
    "relevance": .15, "brand_tone": .10, "citation_support": .10
}

STOP = {"which","their","there","about","these","those","helps","teams","workspace",
        "with","from","this","that","into","only","across","while","information"}

def norm(t):
    return re.sub(r"[^a-z0-9\s]", "", t.lower())

def tokens(t):
    return {x for x in norm(t).split() if len(x)>3 and x not in STOP}

def similarity(a,b):
    A,B=tokens(a),tokens(b)
    if not A or not B: return 0
    return len(A&B)/len(A|B)

def extract_claims(text):
    parts = re.split(r'(?<=[.!?])\s+', text.strip())
    return [p.strip() for p in parts if len(p.strip()) > 8]

def evidence_for_claim(claim, facts):
    ranked=sorted(
        [{"source_id":f["id"],"evidence":f["text"],"similarity":round(similarity(claim,f["text"]),3)}
         for f in facts],
        key=lambda x:x["similarity"], reverse=True)
    return ranked[0]

def claim_evaluation(text, brief):
    rows=[]
    for claim in extract_claims(text):
        ev=evidence_for_claim(claim, brief["approved_facts"])
        supported=ev["similarity"] >= .12
        rows.append({"claim":claim, **ev, "supported":supported})
    return rows

def phrase_coverage(text, phrases):
    nt=norm(text); hits=0
    for phrase in phrases:
        keys=[w for w in norm(phrase).split() if len(w)>3]
        if keys and sum(w in nt for w in keys)/len(keys) >= .6: hits += 1
    return hits/len(phrases) if phrases else 1

def factual_consistency(text, brief):
    lower=text.lower()
    approved=" ".join(x["text"] for x in brief["approved_facts"]).lower()
    penalties=0
    patterns=["publicly","50%","workflow automation","guarantees","guaranteed"]
    for p in patterns:
        if p in lower and p not in approved: penalties += 1
    return max(0,5-1.4*penalties)

def evaluate(text, brief):
    claims=claim_evaluation(text, brief)
    supported=(sum(x["supported"] for x in claims)/len(claims)) if claims else 0
    fact=factual_consistency(text, brief)
    complete=phrase_coverage(text, brief["required_points"])*5
    rel=max(0,min(5,3.5+phrase_coverage(text,brief["required_points"])*1.5-(1 if len(text.split())>120 else 0)))
    violations=sum(term in text.lower() for term in brief["brand_rules"]["avoid"])
    brand=max(0,5-2*violations)
    grounded=min(5,(supported*.6+(fact/5)*.4)*5)
    evidence_score=min(5, 2.5 + supported*2.5)

    scores={
      "groundedness":round(grounded,2),
      "factual_consistency":round(fact,2),
      "completeness":round(complete,2),
      "relevance":round(rel,2),
      "brand_tone":round(brand,2),
      "citation_support":round(evidence_score,2)
    }
    total=round(sum((scores[k]/5)*WEIGHTS[k]*100 for k in WEIGHTS),1)
    # Critical-dimension guardrail: an aggregate score cannot hide material
    # incompleteness. This mirrors risk-based production routing.
    if fact < 2.5 or grounded < 2.5:
        decision = "FAIL"
    elif complete < 3.5:
        decision = "HUMAN REVIEW" if total >= 70 else "FAIL"
    else:
        decision = "PASS" if total >= 85 else ("HUMAN REVIEW" if total >= 70 else "FAIL")
    return {"scores":scores,"quality_score":total,"decision":decision,"claims":claims}
