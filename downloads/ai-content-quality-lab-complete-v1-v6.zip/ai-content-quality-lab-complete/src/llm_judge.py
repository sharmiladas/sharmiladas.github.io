"""
V2: LLM-as-a-Judge adapter.

The default project is runnable without API credentials. `build_judge_prompt`
creates a provider-neutral evaluation request. Replace `call_judge` with an
approved model/provider in a production implementation.
"""
import json

RUBRIC = {
 "groundedness":"Every factual claim should be supported by approved evidence.",
 "factual_consistency":"The answer must not contradict the approved evidence.",
 "completeness":"The answer should include required task information.",
 "relevance":"The answer should remain focused on the requested task.",
 "brand_tone":"The answer should comply with specified voice and prohibited language."
}

def build_judge_prompt(task, evidence, candidate):
    return f"""You are evaluating AI-generated enterprise content.
Return JSON only. Score each rubric dimension 0-5 and explain each score briefly.

TASK:
{task}

APPROVED EVIDENCE:
{json.dumps(evidence, indent=2)}

CANDIDATE:
{candidate}

RUBRIC:
{json.dumps(RUBRIC, indent=2)}
"""

def call_judge(task, evidence, candidate):
    # Offline-safe demonstration. This intentionally does not call a hosted API.
    return {
      "status":"adapter_ready",
      "message":"Connect an approved LLM provider here for model-based judging.",
      "prompt":build_judge_prompt(task,evidence,candidate)
    }
