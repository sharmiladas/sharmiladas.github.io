import json, csv, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
sys.path.insert(0,str(ROOT/"rag"))
sys.path.insert(0,str(ROOT/"knowledge_graph"))

from evaluator import evaluate
from retriever import demo as rag_demo
from graph_context import graph_context

def load(p):
    return json.loads(Path(p).read_text())

brief=load(ROOT/"data/source_brief.json")
outputs=load(ROOT/"data/generated_outputs.json")
corpus=load(ROOT/"data/corpus.json")
graph=load(ROOT/"knowledge_graph/marketing_graph.json")

rows=[]; detail=[]
for item in outputs:
    result=evaluate(item["text"],brief)
    rows.append({"id":item["id"],"label":item["label"],**result["scores"],
                 "quality_score":result["quality_score"],"decision":result["decision"]})
    detail.append({"id":item["id"],"label":item["label"],"text":item["text"],**result})

with open(ROOT/"results/evaluation_results.csv","w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)

(ROOT/"results/claim_evidence.json").write_text(json.dumps(detail,indent=2))

rag_result=rag_demo("beta launch semantic search access invited teams",corpus)
(ROOT/"results/rag_demo.json").write_text(json.dumps(rag_result,indent=2))

kg_result=graph_context(graph,"P1",depth=3)
(ROOT/"results/knowledge_graph_context.txt").write_text("\n".join(kg_result))

print("Pipeline complete.")
for r in rows:
    print(r["id"], r["quality_score"], r["decision"])
