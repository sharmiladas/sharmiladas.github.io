import json
from pathlib import Path
import pandas as pd
import streamlit as st

ROOT=Path(__file__).resolve().parents[1]
st.set_page_config(page_title="AI Content Quality Lab",layout="wide")
st.title("AI Content Quality Lab")
st.caption("Evaluation, evidence, regression and human-review visibility")

df=pd.read_csv(ROOT/"results/evaluation_results.csv")
details=json.loads((ROOT/"results/claim_evidence.json").read_text())

c1,c2,c3=st.columns(3)
c1.metric("Average quality",f'{df["quality_score"].mean():.1f}')
c2.metric("Pass rate",f'{(df["decision"]=="PASS").mean()*100:.0f}%')
c3.metric("Needs review",int((df["decision"]=="HUMAN REVIEW").sum()))

st.subheader("Evaluation results")
st.dataframe(df,use_container_width=True)

st.subheader("Dimension comparison")
dims=["groundedness","factual_consistency","completeness","relevance","brand_tone","citation_support"]
chart=df.set_index("label")[dims]
st.bar_chart(chart)

st.subheader("Claim-level evidence")
choice=st.selectbox("Output", [d["id"] for d in details])
record=next(d for d in details if d["id"]==choice)
st.write(record["text"])
st.dataframe(pd.DataFrame(record["claims"]),use_container_width=True)
