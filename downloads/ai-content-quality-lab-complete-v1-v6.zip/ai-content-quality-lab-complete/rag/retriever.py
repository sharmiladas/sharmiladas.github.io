import json, re
from pathlib import Path

def tok(t):
    return set(re.findall(r"[a-z0-9]+", t.lower()))

def retrieve(query, corpus, k=3):
    q=tok(query)
    scored=[]
    for d in corpus:
        x=tok(d["text"]+" "+d.get("title",""))
        score=len(q & x)/(len(q | x) or 1)
        scored.append({**d,"retrieval_score":round(score,3)})
    return sorted(scored,key=lambda x:x["retrieval_score"],reverse=True)[:k]

def build_context(results):
    return "\n".join(f'[{r["id"]}] {r["text"]}' for r in results)

def demo(query, corpus):
    hits=retrieve(query,corpus)
    return {"query":query,"retrieved":hits,"context":build_context(hits)}
