import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from evaluator import evaluate

brief=json.loads((ROOT/"data/source_brief.json").read_text())
outputs={x["id"]:x for x in json.loads((ROOT/"data/generated_outputs.json").read_text())}
gold=json.loads((ROOT/"data/golden_set.json").read_text())

failures=[]
for g in gold:
    actual=evaluate(outputs[g["id"]]["text"],brief)["decision"]
    ok=actual==g["expected"]
    print(("PASS" if ok else "FAIL"), g["id"], "expected",g["expected"],"actual",actual)
    if not ok: failures.append(g["id"])

if failures:
    raise SystemExit("Regression failures: "+", ".join(failures))
print("All regression gates passed.")
