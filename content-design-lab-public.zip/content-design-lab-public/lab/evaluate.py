#!/usr/bin/env python3
"""Offline teaching harness. Positive=defect. No semantic or model evaluation."""
import argparse
import csv
import json
from collections import Counter
from pathlib import Path

REQUIRED = {"case_id", "surface", "message", "max_chars", "rater_a_defect",
            "rater_b_defect", "reference_defect", "grader_defect"}

def divide(a, b):
    return a / b if b else None

def agreement(a, b):
    n = len(a)
    if not n:
        return {"n": 0, "agreement": None, "kappa": None}
    po = sum(x == y for x, y in zip(a, b)) / n
    pa, pb = sum(a) / n, sum(b) / n
    pe = pa * pb + (1-pa) * (1-pb)
    return {"n": n, "agreement": po, "kappa": divide(po-pe, 1-pe)}

def confusion(reference, predicted):
    c = Counter(zip(reference, predicted))
    tp, fp, fn, tn = c[1,1], c[0,1], c[1,0], c[0,0]
    return {"n": len(reference), "tp": tp, "fp": fp, "fn": fn, "tn": tn,
            "precision": divide(tp, tp+fp), "recall": divide(tp, tp+fn),
            "false_positive_rate": divide(fp, fp+tn),
            "accuracy": divide(tp+tn, len(reference))}

def summarize(rows):
    return {
        "human_independent_agreement": agreement(
            [r["rater_a_defect"] for r in rows],
            [r["rater_b_defect"] for r in rows]),
        "grader_vs_adjudicated_reference": confusion(
            [r["reference_defect"] for r in rows],
            [r["grader_defect"] for r in rows]),
        "length_check_failures": sum(len(r["message"]) > r["max_chars"] for r in rows),
        "note": "Supplied labels only. Length check is not a semantic quality grade."
    }

def load(path):
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        missing = REQUIRED - set(reader.fieldnames or [])
        if missing:
            raise ValueError("Missing columns: " + ", ".join(sorted(missing)))
        rows = list(reader)
    if not rows:
        raise ValueError("Input contains no cases")
    ids = set()
    for row in rows:
        if not row["case_id"] or row["case_id"] in ids:
            raise ValueError("Empty or duplicate case_id: " + row["case_id"])
        ids.add(row["case_id"])
        for col in ("rater_a_defect", "rater_b_defect", "reference_defect", "grader_defect"):
            if row[col] not in ("0", "1"):
                raise ValueError(f"{row['case_id']}: {col} must be 0 or 1")
            row[col] = int(row[col])
        row["max_chars"] = int(row["max_chars"])
        if row["max_chars"] < 1:
            raise ValueError("max_chars must be positive")
    return rows

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--out", type=Path, default=Path("results"))
    args = parser.parse_args()
    try:
        rows = load(args.input)
    except (ValueError, OSError) as e:
        parser.error(str(e))
    args.out.mkdir(parents=True, exist_ok=True)
    report = {"overall": summarize(rows), "by_surface": {
        surface: summarize([r for r in rows if r["surface"] == surface])
        for surface in sorted({r["surface"] for r in rows})}}
    (args.out/"summary.json").write_text(json.dumps(report, indent=2)+"\n")
    fields = ["case_id", "surface", "message", "chars", "length_pass",
              "rater_agreement", "reference_defect", "grader_defect", "grader_result"]
    with (args.out/"cases.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            key = (r["reference_defect"], r["grader_defect"])
            writer.writerow({
                "case_id": r["case_id"], "surface": r["surface"], "message": r["message"],
                "chars": len(r["message"]), "length_pass": len(r["message"]) <= r["max_chars"],
                "rater_agreement": r["rater_a_defect"] == r["rater_b_defect"],
                "reference_defect": r["reference_defect"], "grader_defect": r["grader_defect"],
                "grader_result": {(1,1):"TP",(0,1):"FP",(1,0):"FN",(0,0):"TN"}[key]})
    print(json.dumps(report["overall"], indent=2))
    print("Saved summary.json and cases.csv to", args.out)

if __name__ == "__main__":
    main()
