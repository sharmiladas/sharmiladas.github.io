# Local evaluation lab

Run from the package root:
```bash
python3 lab/evaluate.py lab/sample_reviews.csv --out lab/results
```

Python 3 standard library only. The fictional messages, reference labels, grader labels, and reviewer labels are authored fixtures. They are not outputs collected from real users, reviewers, or a model. The script tests evaluation mechanics, not production quality.

## Columns
- case_id: unique scenario/output record; use a new ID for each repeat in a separate analysis.
- surface: used for descriptive slices.
- message, max_chars: deterministic length check; Python Unicode code-point count.
- rater_a_defect, rater_b_defect: preserved independent judgments.
- reference_defect: separately adjudicated label used as a reference.
- grader_defect: saved automated judgment to compare with that reference.
- context, expected_behavior, rationale: explanatory fixture context; the script does not interpret them.

Defect=1; no defect=0. All records require binary labels. Unreviewed records should stay outside this file until reviewed, with their missing status tracked separately. Do not silently discard missing labels in a production report.

## Read the report
summary.json contains independent human agreement/kappa and grader/reference confusion metrics overall and by surface. cases.csv shows each classification and length check. Null means a denominator is zero; it does not mean a perfect result.

Small surface slices are descriptive. They do not support claims of reliable population performance. The sample includes a false negative, false positives, disagreements, a guaranteed-outcome claim, and an intentionally long message.

## Exercises
1. Predict the metrics by hand; compare with summary.json.
2. Explain each FP and FN using context and rationale.
3. Draft a rubric change without changing the saved reference merely to improve scores.
4. Collect fresh labeled examples and rerun. Record versions.
5. For repeatability, collect repeated grader decisions per unchanged case and compute the fraction that flip. This script does not compute repeated-run stability; do not interpret inter-rater kappa as that measure.
6. Extend the report with risk slices and confidence intervals only after choosing an appropriate statistical design.

## Extension boundary
This harness does not call an API, generate content, create expert labels, validate source truth, run significance tests, compute ordinal-score reliability, or establish retention impact. Use the toolkit's handoff contract to plan those additions.
