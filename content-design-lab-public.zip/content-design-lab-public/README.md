# Content Design Lab

Six articles, toolkit, templates and a local evaluation exercise.

Run: python3 lab/evaluate.py lab/sample_reviews.csv --out lab/results

Python 3 standard library only. Sample labels and messages are fictional teaching data, not production results. See TOOLKIT.md and SOURCES.md.
