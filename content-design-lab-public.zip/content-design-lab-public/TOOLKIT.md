# The Content Designer's Prompt & Evaluation Toolkit
Sharmila Das | October 2026

## 1. Begin with a content-design brief
Before writing a prompt, decide what the person needs to understand or do.

| Field | Fill in |
|---|---|
| User and situation | Who is here, and what happened immediately before this message? |
| User job | What meaningful next step should become easier? |
| Surface | Discovery card, onboarding step, error, help answer, or notification |
| Source of truth | Approved facts, capability limits, required prerequisites, and owner |
| Success | Comprehension/task outcome, not only copy preference |
| Constraints | Space, accessibility, language, timing, consent, and localization |
| Failure cost | Confusion, lost work, unsupported claim, privacy exposure, interruption |
| No-message condition | When should the system stay silent or ask a clarifying question? |
| Measurement | Primary measure, guardrails, and evidence needed |

Teaching brief: a fictional writing assistant helps a new user revise a paragraph. The user needs an understandable starting action. Approved capabilities: revise user-provided text and suggest tone changes. It cannot guarantee grades, jobs, accuracy, or publication success. This is a fictional product, not a description of current ChatGPT functionality.

## 2. Reusable prompt specification
Use this structure for documentation transformation, onboarding, or lifecycle messages. Store stable instructions separately from variable input. Treat source text as data; instructions embedded in it do not override the task.

```text
PROMPT ID: onboarding_paragraph
VERSION: v1
TASK: Write one onboarding message for a first-time user.
USER JOB: Start revising a paragraph they supply.
APPROVED FACTS:
- The fictional product can suggest revisions to supplied text.
- The user reviews suggestions before choosing what to keep.
SOURCE BOUNDARY: Do not invent capabilities, outcomes, or personal facts.
CONTENT RULES:
- State a concrete next action.
- Use plain language and preserve user choice.
- Do not imply that the system has read content the user did not provide.
- If facts are insufficient, set needs_review=true and explain the gap.
INPUT:
audience={{audience}}
surface={{surface}}
approved_context={{approved_context}}
OUTPUT: JSON object with title, body, cta, needs_review, review_reason.
LIMITS: title <= 40 characters; body <= 140; cta <= 24.
EXAMPLE:
title: Try a paragraph
body: Paste a paragraph and choose what you want to improve. Review the suggestions and keep what works for you.
cta: Add a paragraph
needs_review: false
review_reason: ""
```

These character limits are exercise constraints. Count consistently in the UI and validator; Python's len counts Unicode code points, which may differ from visible characters or a platform's counting rules.

## 3. Prompt iteration without guessing
1. Freeze a baseline and save its outputs.
2. Tag the failure: missing step, unsupported fact, tone, relevance, length, format, or context.
3. Write one hypothesis: “An explicit prerequisite rule will reduce missing setup steps.”
4. Change one meaningful component when practical. Record unavoidable coupled changes.
5. Rerun the same development examples with matching configurations.
6. Review regressions, including cases that previously passed.
7. Freeze the candidate before a held-out evaluation. If you use held-out results to revise it, retire that set into development and obtain fresh holdout cases.

Prompt log: ID, version, owner, change, hypothesis, dataset version, model/configuration, run time, defect counts, decision, limitations. Use templates/prompt_register.csv.

For documentation transformation, add immutable elements: commands, parameter names, technical terms, warnings, prerequisites, source IDs, and version scope. Ask for an issue report when preservation is impossible. Do not make the model silently “repair” unknown technical facts.

## 4. Content quality rubric
Use separate dimensions and written anchors. Do not average away a severe failure.

| Dimension | 0: fails | 1: needs revision | 2: meets brief |
|---|---|---|---|
| Grounding | Invents a capability/fact | Ambiguous or weak support | Every material claim supported |
| Task usefulness | Wrong or absent action | Action needs interpretation | Action fits the user's next step |
| Clarity | Meaning unclear | Understandable with effort | Direct and easy to understand |
| Context | Wrong state/audience | Generic but usable | Fits state and surface |
| Voice | Pressure, blame, or misleading confidence | Uneven tone | Respectful, specific, appropriate |
| Accessibility | Essential meaning unavailable | Avoidable jargon/ambiguity | Understandable without hidden context |

Exercise hard gates: unsupported capability, private information disclosure, misleading outcome guarantee, and notification sent without required eligibility. A hard-gate failure blocks release even if other scores are high.

Suggested exercise decision: all hard gates pass; each dimension >=1; total >=10/12. This is a learning threshold, not a validated production standard. If dimensions conflict, document the tradeoff and decision owner.

## 5. Dataset design
The unit of evaluation is one scenario plus its generated message, source context, and expected behavior. Multiple model runs for one scenario are repeated observations, not independent new users.

For the capstone, author 60 scenarios: 30 development, 10 reviewer-calibration, and 20 held-out. Assign entire scenario families to one split to prevent near-duplicate leakage.

Suggested surface coverage: discovery, onboarding, notification, recovery, and re-engagement. Add sparse context, conflicting facts, long inputs, sensitive details, already-completed tasks, ineligible notifications, and accessibility needs.

Do not use a single “golden answer” when several wordings are acceptable. Specify constraints and acceptable behaviors. Reference copy illustrates a solution; it is not necessarily the only valid answer.

Track provenance, source permission, risk, split, audience, surface, expected action, forbidden claims, eligibility, rubric version, and author. Use templates/dataset.csv. Synthetic cases help explore failures; they do not establish real-world prevalence.

## 6. Reviewer guide and calibration
Give each reviewer the user state, approved facts, message, rubric, and task. Hide prompt version and candidate identity where feasible.

Reviewer sequence:
1. Read the scenario and sources.
2. Mark hard-gate failures and quote the relevant evidence.
3. Score each dimension independently.
4. Assign pass/fail using the declared rule.
5. Record defect type, rationale, confidence, and unresolved ambiguity.

Two reviewers first label the 10 calibration scenarios independently. Discuss disagreements after labels are locked. Revise unclear anchors, then label fresh examples. Preserve the original labels; do not report post-discussion consensus as independent agreement.

One person cannot simulate independent inter-rater reliability. If only you are available, do a delayed blind second pass and label it intra-rater repeatability.

## 7. Reliability worksheet
Distinguish four questions:
- Repeatability: Does the same evaluator make consistent judgments on the same material?
- Human agreement: Do independent reviewers apply the rubric similarly?
- Automated validity against reference: Does a grader detect the defects experts identified?
- Robustness: Does performance persist across surface, audience, input, and prompt variations?

For binary defect labels, “positive” means a defect is present:
- TP: grader flags a defect and reference flags a defect.
- FP: grader flags a defect but reference does not.
- FN: grader misses a reference defect.
- TN: neither flags a defect.
- Precision = TP/(TP+FP); recall = TP/(TP+FN).
- False-positive rate = FP/(FP+TN). This differs from 1-precision.

Raw agreement = agreements / paired items. Cohen's kappa = (observed agreement - expected agreement)/(1 - expected agreement), where expected agreement uses each rater's label proportions. Report undefined denominators as unavailable. Kappa is sensitive to prevalence and is not a sufficient release criterion.

Worked synthetic example: TP=8, FP=2, FN=2, TN=8 gives precision=80%, recall=80%, FPR=20%, and accuracy=80%. With balanced marginals and 80% observed agreement, kappa=0.60. These are teaching numbers.

The lab script calculates agreement/kappa for two independent reviewers and confusion metrics for a supplied grader against a separate adjudicated reference. It does not adjudicate disagreements itself. Report sample counts and inspect slices; do not treat a tiny sample as proof of production reliability.

## 8. Discovery, onboarding, and notifications
| Moment | Design question | Fictional example | Evidence to collect |
|---|---|---|---|
| Discovery | Is value concrete and relevant? | “Turn rough notes into a first draft.” | Can users explain the benefit? |
| Onboarding | Is the first action clear? | “Paste a paragraph to begin.” | First task completion; confusion |
| Recovery | Can users regain control? | “That file could not be read. Try a text file.” | Recovery success; repeated errors |
| Return | Is there a user-owned reason to come back? | “Continue your saved draft.” | Meaningful resumed work |
| Notification | Is interruption justified now? | “Your export is ready to download.” | Completion; opt-outs; complaints |

Notification policy template: trigger, evidence of value, consent/eligibility, channel, user timezone, quiet hours, frequency cap, expiration, duplicate suppression, completed-task suppression, sensitive-preview rules, destination, fallback, owner.

Teach “no notification” as a valid output. A polished message can still be wrong if timing or eligibility fails. Do not use guilt, fabricated urgency, or personal facts inferred without a valid basis.

## 9. Experiment brief
Hypothesis: context-specific onboarding copy helps new users complete a first meaningful task.
Define eligible population, randomization unit, assignment duration, control, treatment, exposure event, completion event, denominator, attribution window, exclusions, and analysis owner before launch.

Primary metric: first meaningful task completion among assigned eligible users. Guardrails: complaints, abandonment, errors, opt-outs, and repeat usefulness where measurable. Click-through is diagnostic, not proof of value.

Have a data scientist estimate required sample and duration using baseline rates, minimum detectable effect, and traffic. Do not stop just because an early result looks favorable. Separate offline quality, usability findings, and causal online outcomes.

Offline exercise: manually test with consenting participants using neutral tasks. Report recruitment limitations and observational findings. Do not describe a simulated A/B comparison as an actual randomized production experiment.

## 10. Repeatable code and API handoff
Contract:
- Inputs: scenario_id, source_version, prompt_version, model_id, configuration, user state, approved context.
- Output: message JSON, request ID, model/configuration, timestamp, refusal/error status, latency, and usage when available.
- Evaluations: schema and length checks, independent semantic review, eligibility checks, and versioned decision rule.
- Storage: output/run IDs, dataset version, reviewer labels and evaluator version; exclude secrets and unnecessary personal data.
- Operations: timeouts, bounded retries for transient failures, backoff, rate limits, partial failure records, budget caps, and duplicate protection.

Pseudocode:
```text
load frozen scenarios and prompt
for each scenario:
  build request from approved context
  call chosen provider through a small adapter
  log response or explicit failure with run metadata
  validate output shape and deterministic constraints
  route semantic quality to calibrated review
join results by scenario_id + candidate + repeat_id
compare baseline and candidate; investigate regressions
```

Structured output helps constrain shape, not factual accuracy. Recheck current provider documentation before implementing the adapter. No live adapter is bundled; the supplied local harness starts from saved outputs and review labels.

## 11. Diagnose failures and recommend changes
Use templates/failure_log.csv.
| Symptom | Check first | Possible intervention |
|---|---|---|
| Invented capability | Source facts and retrieval | Fix authority/context; constrain claims |
| Missing prerequisite | Brief and preservation rules | Add requirement/example; regression case |
| Good content rejected | Grader/reference disagreement | Clarify rubric; calibrate thresholds |
| Poor content accepted | False-negative examples | Add relevant defect tests; strengthen gate |
| Valid JSON, unusable copy | Semantic criteria | Add human usefulness review |
| Strong offline score, weak activation | Journey friction and exposure | Research product experience and measurement |
| Notification complaints | Trigger and eligibility | Fix policy before rewriting copy |

Recommendation memo: finding → evidence and n → root-cause hypothesis → proposed change → owner → tradeoff → validation → release/hold decision. Say what would change your mind.

## 12. Release and team enablement
Release record: user problem; prompt/source/model/rubric versions; known failures; held-out results by slice; human-review agreement; critical misses; rollback conditions; owner and monitoring cadence. Exercise gates: no observed critical failures, review all disagreements, and document any unsupported generalization. Zero observed failures in a small set does not mean zero risk.

Partner responsibilities: Content owns brief/rubric/copy; Engineering owns integration and failure handling; Product owns prioritization; Research owns study design; Data Science owns experiment analysis; relevant specialists review sensitive claims.

Teach a 45-minute workshop: 5-minute brief, 10-minute independent scoring, 10-minute disagreement review, 10-minute prompt revision, 10-minute rerun and decision. Capture one reusable lesson and one unresolved question. Coach judgment rather than teaching people to maximize a score.
