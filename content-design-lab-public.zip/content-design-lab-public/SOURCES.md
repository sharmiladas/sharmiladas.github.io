# Primary references
Checked October 28, 2026. These links support the general technical background; the toolkit's examples, schedules, rubrics, and decision thresholds are original teaching designs.

1. OpenAI, Prompt engineering: https://developers.openai.com/api/docs/guides/prompt-engineering
   Reference for clear instructions, context, examples, and prompt organization.
2. OpenAI, Evaluation best practices: https://developers.openai.com/api/docs/guides/evaluation-best-practices
   Reference for task-specific tests, representative data, and human calibration. Some hosted evaluation workflows are labeled legacy in current navigation; the local exercise deliberately avoids depending on that product interface.
3. OpenAI, Structured model outputs: https://developers.openai.com/api/docs/guides/structured-outputs
   Reference for schema-constrained output. A valid schema does not establish that the content is correct.
4. van der Lee et al., 2019, Best practices for the human evaluation of automatically generated text: https://aclanthology.org/W19-8643/
   Reference for explicit evaluation design and consistent human-review procedures.

Independent learning materials for content design in AI products.

No model names, prices, or time-sensitive SDK signatures are hardcoded. The API handoff is an implementation contract and pseudocode, not a tested live integration.
