# Design for a Meaningful Next Step
By Sharmila Das

Discovery, onboarding, and notifications operate at different moments. Discovery helps someone recognize a useful possibility. Onboarding helps them begin. A notification asks them to interrupt something else. Applying one “engaging” tone to all three misses the decision each message must support.

For discovery, make the value concrete. A fictional writing product might offer “Turn rough notes into a first draft.” The person can judge whether that is relevant. “Unlock your creativity” leaves the actual benefit harder to assess.

For onboarding, connect the promise to an achievable action. “Paste a paragraph to begin” tells the person what to supply. If there is a necessary choice or limitation, explain it at the point it matters. The goal is an understandable first success, not completion of a tour.

Notifications require another layer of judgment. Even useful words can be wrong when the trigger is stale, the person already completed the task, or the preview reveals something sensitive. A notification design needs eligibility, timing, frequency, expiration, and destination rules alongside the copy.

Consider “Your export is ready.” Before sending, the system should know an export actually completed, that the person requested it, that the message is still relevant, and that its link leads to the correct place. If those conditions fail, rewriting the sentence does not fix the experience.

Measurement should follow the user purpose. A high click rate may indicate curiosity or confusion. For onboarding, examine completion of a meaningful task and whether the person understood the action. For notifications, examine useful task completion alongside opt-outs, complaints, and interruption burden.

A portfolio exercise can make these tradeoffs visible without claiming a production launch. Create a fictional journey, write alternatives, document no-message conditions, test comprehension with consenting participants, and state what would need an online experiment.

**Try it:** Write one discovery card, one onboarding message, one recovery message, and one notification for the same fictional product. For each, specify the user state, intended action, failure condition, and measurement. Write a fifth example in which the correct decision is to send nothing.

**Method note:** These examples and recommendations are original product-design exercises aligned to the supplied job description. They describe no actual OpenAI notification policy or product capability.
