# Turn Editorial Judgment into an Evaluation People Can Use
By Sharmila Das

“This copy feels wrong” can be the start of useful feedback. It cannot be the entire evaluation system. A repeatable assessment needs to identify what failed, why it matters, and what evidence would support a different judgment.

Start with the user task. An onboarding message should help a person understand the next action. A recovery message should explain a problem and a workable next step. A notification should provide enough value to justify an interruption. Those purposes require different criteria even when all three messages share the same voice.

Next, separate dimensions. Clarity asks whether the meaning is understandable. Grounding asks whether claims have support. Context asks whether the message fits the person's state. A clear message can still be factually wrong. One combined “quality” score can hide that distinction.

Use anchored judgments. A clarity score of zero might mean the intended action is unclear. One could mean the action is understandable after interpretation. Two could mean the next action is explicit and appropriate. Reviewers need examples at the boundary, including cases with more than one acceptable wording.

Some failures should block release regardless of the average. An invented product capability is not repaired by excellent tone. A notification that exposes sensitive information is not rescued by a short headline. Decide which failures are gates before examining candidate results.

Then design the dataset. Include ordinary use, sparse context, conflicting source material, already-completed tasks, and known failure patterns. Label the expected behavior instead of forcing every output to resemble one reference sentence. Divide scenario families between development and held-out assessment so near duplicates do not create an exaggerated impression of generalization.

The result should help people act. A report that says “quality fell” is less useful than one showing that missing prerequisites increased in recovery scenarios after a prompt change. That finding points to a specific investigation and a regression test.

For a small portfolio project, publish the rubric, scenario coverage, failure examples, and release recommendation alongside the aggregate results. Explain the sample's limits. A carefully documented small evaluation demonstrates judgment; it does not establish production-wide performance.

**Try it:** Write a six-dimension rubric for five fictional messages. Add two hard gates. Ask another reviewer to apply it independently, then identify which definitions produced disagreement.

**Reference:** OpenAI's [evaluation best practices](https://developers.openai.com/api/docs/guides/evaluation-best-practices) provides general background on task-specific assessment. The rubric and gates in the companion toolkit are proposed exercise rules.
