# Prompts Are Content Design Specifications
By Sharmila Das

A prompt starts with a decision about what someone needs to understand or do. The model instruction comes later. If the user problem is unclear, more elaborate instructions can produce consistent output that solves the wrong problem.

Consider a fictional writing assistant onboarding a new user. “Write engaging onboarding copy” leaves several decisions unresolved. What can the product actually do? What does the user need to supply? What happens after the button? What should the system avoid promising?

A useful brief answers those questions before generation. The product can revise text supplied by the user. The person needs to paste a paragraph and choose a goal. Suggestions remain optional. The message should make that next action understandable without promising a better grade, a job offer, or another unsupported result.

The prompt can then encode the design: approved facts, audience, user state, action, voice, constraints, and output structure. “Paste a paragraph to begin” follows from the interaction. It is not simply a friendlier version of a vague instruction.

Documentation transformation makes this relationship especially visible. A prompt must preserve more than meaning in the abstract. Commands, parameter names, prerequisites, version conditions, and warnings may carry functional consequences. The instruction should identify what can change, what must remain intact, and when an uncertainty requires review.

The first output is a design test. Suppose a transformed document loses a prerequisite. Adding “be accurate” gives little guidance. A stronger revision identifies prerequisite preservation explicitly, includes a representative example, and requires an issue report when source material is incomplete. The revised prompt then needs regression testing against cases it previously handled well.

This creates a practical division of responsibility. Content design defines acceptable communication and the user task. Engineering implements the repeatable workflow. Evaluation tests whether the resulting behavior meets the specification. Each contributes to a usable system.

For a portfolio, show that chain. Include a brief, an initial prompt, a failed output, the reasoning behind a revision, and the results of a controlled comparison. Describe failures that remain. The strongest evidence is a defensible design decision that changed system behavior.

**Try it:** Choose one message. Write its user job, source boundary, required action, and three failure conditions. Build two prompt versions and explain the specific behavior each change is intended to improve.

**Technical reference:** OpenAI's [prompt engineering guide](https://developers.openai.com/api/docs/guides/prompt-engineering) provides background on instructions, context, and examples. The fictional exercise and design framework above are original teaching material.
