# Test the Evaluator Before Trusting the Score
By Sharmila Das

An automated grader can make content review faster while creating a new source of error. It may reject useful content, overlook a serious defect, or apply the same criterion inconsistently. A quality score becomes useful only when we understand the behavior behind it.

Begin with a reference. Two reviewers independently examine the same examples using written criteria. Preserve their initial judgments. Discuss disagreements afterward and record a separate adjudicated decision. Otherwise, the process can confuse consensus achieved through discussion with independent agreement.

Human disagreement is informative. If reviewers disagree about whether a claim is supported, the source boundary may be unclear. If they disagree about tone, the rubric may need examples. Do not automatically treat the majority opinion as an unquestionable fact.

Compare the automated labels with the adjudicated reference. Define the positive label explicitly. In the companion lab, positive means a defect is present. A false positive is acceptable content incorrectly flagged. A false negative is a defect the grader missed.

These errors have different consequences. Too many false positives create review burden and reduce trust. False negatives allow poor content through. Precision tells you how often flags correspond to reference defects. Recall tells you how many reference defects the grader caught. The acceptable tradeoff depends on the failure cost and the review workflow.

Repeatability is another question. Run the evaluator several times on unchanged inputs and preserve the configuration. Then inspect whether decisions change, especially near the release boundary. Repeated runs of the same scenario should not be counted as independent evidence about a broader user population.

Agreement metrics also need context. Raw agreement can look high when nearly every example belongs to one class. Cohen's kappa accounts for agreement expected from the raters' label proportions, but it is sensitive to prevalence. Neither statistic replaces examining critical misses and performance by content type.

When improving the grader, keep a separate evaluator test set. If you repeatedly tune criteria against the same examples, the score can improve without demonstrating broader reliability. Document what changed and what remains uncertain.

**Try it:** Run the bundled script, inspect each false positive and false negative, and propose one rubric change. Evaluate that change on fresh examples before declaring improvement.

**Reference:** [van der Lee et al. (2019)](https://aclanthology.org/W19-8643/) reviews variation in human evaluation and argues for more consistent procedures. The local lab's metrics are diagnostic teaching tools, not validated release standards.
